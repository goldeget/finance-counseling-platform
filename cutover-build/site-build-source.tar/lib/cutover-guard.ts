import {env} from 'cloudflare:workers';
import {shouldFreeze} from './cutover-policy.mjs';
export function cutoverFrozen():boolean {
  return shouldFreeze((env as unknown as Record<string,string>).FINANCE_FREEZE_UNTIL);
}
export function cutoverResponse():Response {
  return Response.json({error:'서비스 이전 작업 중입니다. 잠시 후 다시 시도해 주세요.'},{status:503,headers:{'Cache-Control':'no-store','Retry-After':'300'}});
}
