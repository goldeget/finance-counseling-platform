import {test} from 'node:test';
import assert from 'node:assert/strict';
import {shouldFreeze} from '../lib/cutover-policy.mjs';
test('write freeze expires automatically and malformed configured values fail closed',()=>{
  assert.equal(shouldFreeze(undefined,100),false);
  assert.equal(shouldFreeze('200',100),true);
  assert.equal(shouldFreeze('200',200),false);
  assert.equal(shouldFreeze('invalid',100),true);
});
