import {test} from 'node:test';
import assert from 'node:assert/strict';
import {authorisedTransfer} from '../lib/transfer-auth.mjs';
test('transfer access requires the correct unexpired secret',async()=>{
  const s='a'.repeat(64);
  assert.equal(await authorisedTransfer(s,s,'200',100),true);
  assert.equal(await authorisedTransfer('b'.repeat(64),s,'200',100),false);
  assert.equal(await authorisedTransfer(s,s,'99',100),false);
  assert.equal(await authorisedTransfer('',s,'200',100),false);
  assert.equal(await authorisedTransfer(s,s,'bad',100),false);
});
