import {cutoverFrozen} from '../../../lib/cutover-guard';
export const dynamic='force-dynamic';
export async function GET(){return Response.json({frozen:cutoverFrozen()},{headers:{'Cache-Control':'no-store'}})}
