import {env} from 'cloudflare:workers';
import {decryptRecord} from '../../../lib/application-crypto';
import {authorisedTransfer} from '../../../lib/transfer-auth.mjs';
export const dynamic='force-dynamic';
const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const reply=(body:object,status=200)=>Response.json(body,{status,headers});
const config=env as unknown as Record<string,string>;
const b64=(b:Uint8Array)=>btoa(String.fromCharCode(...b));
export async function GET(request:Request){
  if(!await authorisedTransfer(request.headers.get('x-transfer-token')||'',config.FINANCE_TRANSFER_TOKEN,config.FINANCE_TRANSFER_EXPIRES))return reply({error:'접근 권한이 없습니다.'},403);
  const q=new URL(request.url).searchParams,type=q.get('type'),after=q.get('after')||'';
  if(after.length>200)return reply({error:'위치를 확인해 주세요.'},400);
  try{
    if(type==='summary'){
      const reviews=await env.DB.prepare('SELECT COUNT(*) AS n FROM reviews').first<{n:number}>();
      const applications=await env.DB.prepare('SELECT COUNT(*) AS n FROM applications').first<{n:number}>();
      return reply({reviews:Number(reviews?.n||0),applications:Number(applications?.n||0)});
    }
    if(type==='reviews'){
      const r=await env.DB.prepare('SELECT id,author,source,rating,content,review_date,created_at FROM reviews WHERE id > ? ORDER BY id LIMIT 500').bind(after).all<{id:string}>();
      return reply({items:r.results,next:r.results.length===500?r.results[r.results.length-1].id:null});
    }
    if(type==='applications'){
      const raw=Uint8Array.from(atob(config.FINANCE_TRANSFER_KEY||''),c=>c.charCodeAt(0));
      if(raw.length!==32)throw Error('Invalid destination key');
      const key=await crypto.subtle.importKey('raw',raw,{name:'AES-GCM'},false,['encrypt']);
      const r=await env.DB.prepare('SELECT id,reference,created_at,iv,ciphertext FROM applications WHERE id > ? ORDER BY id LIMIT 100').bind(after).all<{id:string;reference:string|null;created_at:string;iv:string;ciphertext:string}>();
      const items=await Promise.all(r.results.map(async row=>{
        const plain=await decryptRecord(row.iv,row.ciphertext),iv=crypto.getRandomValues(new Uint8Array(12));
        const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,new TextEncoder().encode(JSON.stringify(plain)));
        return {id:row.id,reference:row.reference,created_at:row.created_at,iv:b64(iv),ciphertext:b64(new Uint8Array(cipher))};
      }));
      return reply({items,next:r.results.length===100?r.results[r.results.length-1].id:null});
    }
    return reply({error:'요청 종류를 확인해 주세요.'},400);
  }catch{return reply({error:'이전 자료를 불러오지 못했습니다.'},503)}
}
